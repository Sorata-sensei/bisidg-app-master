<?php echo $__env->make('students.template.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<div class="admin-container">
    <?php echo $__env->make('students.message.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('students.template.sidenav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Main Content -->
    <main class="main-content">
        <header class="header">
            <div>
                <h2>Selamat <?php echo e($greeting); ?></h2>
            </div>
            <div class="user-profile">
                <div class="profile-img">
                    <?php echo e(collect(explode(' ', session('student_nama')))->map(fn($word) => strtoupper(substr($word, 0, 1)))->join('')); ?>

                </div>

                <div class="dropdown">
                    <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <?php echo e(session('student_nama')); ?>

                    </a>

                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>

        </header>

        <?php echo $__env->yieldContent('content'); ?>
    </main>


    <?php echo $__env->make('students.template.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>

<?php echo $__env->make('students.template.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/students/template/index.blade.php ENDPATH**/ ?>