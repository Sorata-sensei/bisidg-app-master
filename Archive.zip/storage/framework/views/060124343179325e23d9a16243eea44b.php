
<?php $__env->startPush('css'); ?>
    <style>
        .card-header {
            background-color: transparent !important;
            border-bottom: none !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Dashboard Cards -->
    <div class="dashboard-grid">
        <div class="card col-xl-3 col-md-6 mb-4">
            <div class="card-header">
                <div class="card-title">Total Counseling</div>
                <div class="card-icon">👥</div>
            </div>
            <div class="card-value"><?php echo e($counseling); ?></div>
            <div class="card-subtitle">Counseling di setiap semester</div>
        </div>
    </div>

    <!-- Chart Section -->
    

    <!-- Additional Content -->
    
    <!-- Content Row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('students.template.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/students/dashboard/index.blade.php ENDPATH**/ ?>