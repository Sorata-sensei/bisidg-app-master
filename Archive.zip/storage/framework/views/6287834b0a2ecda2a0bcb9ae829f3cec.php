<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('auth.template.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('css'); ?>
<style>
    .toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1055;
    }
</style>

</head>

<body>
    <?php echo $__env->make('message.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>
</body>
<?php echo $__env->make('auth.template.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

</html>
<?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/auth/template/index.blade.php ENDPATH**/ ?>