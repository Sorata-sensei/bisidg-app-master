<?php $__env->startPush('css'); ?>
    <style>
        .form-control:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, .25);
        }

        .btn-primary {
            background: #4361ee;
            border: none;
            border-radius: 6px;
            padding: 12px 24px;
            font-weight: 600;
        }

        .btn-primary:hover {
            background: #3a56d4;
        }

        .card {
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, .1);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        /** @var \App\Models\User $user */
        $isEdit = isset($user) && $user->exists;
    ?>

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header <?php echo e($isEdit ? 'bg-info text-white' : 'bg-success text-white'); ?>">
                        <h5 class="mb-0">
                            <i class="fas fa-user-edit me-2"></i>
                            <?php echo e($isEdit ? 'Edit User - ' . $user->name : 'Tambah User'); ?>

                        </h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e($isEdit ? route('user.admin.update', $user->id) : route('user.admin.store')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if($isEdit): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>

                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" class="form-control form-control-lg"
                                    value="<?php echo e(old('name', $user->name)); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" name="username" id="username" class="form-control form-control-lg"
                                    value="<?php echo e(old('username', $user->username)); ?>">
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="NIDNorNUPTK" class="form-label">NIDN / NUPTK</label>
                                <input type="text" name="NIDNorNUPTK" id="NIDNorNUPTK"
                                    class="form-control form-control-lg"
                                    value="<?php echo e(old('NIDNorNUPTK', $user->NIDNorNUPTK)); ?>">
                                <?php $__errorArgs = ['NIDNorNUPTK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="role" class="form-label">Role</label>
                                <select name="role" id="role" class="form-control form-control-lg">
                                    <?php $roleNow = old('role', $user->role ?? 'admin'); ?>
                                    <option value="admin" <?php echo e($roleNow == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                    <option value="dosen" <?php echo e($roleNow == 'dosen' ? 'selected' : ''); ?>>Dosen</option>
                                    <option value="mahasiswa" <?php echo e($roleNow == 'mahasiswa' ? 'selected' : ''); ?>>Mahasiswa
                                    </option>
                                    <option value="superadmin" <?php echo e($roleNow == 'superadmin' ? 'selected' : ''); ?>>Superadmin
                                    </option>
                                    <option value="masteradmin" <?php echo e($roleNow == 'masteradmin' ? 'selected' : ''); ?>>
                                        Masteradmin
                                    </option>
                                </select>
                                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email" class="form-control form-control-lg"
                                    value="<?php echo e(old('email', $user->email)); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="photo" class="form-label">Foto</label>
                                <input type="file" name="photo" id="photo" class="form-control form-control-lg"
                                    accept="image/*">
                                <?php if($isEdit && $user->photo): ?>
                                    <div class="mt-2">
                                        <img src="<?php echo e(asset('storage/' . $user->photo)); ?>" alt="Foto"
                                            class="img-thumbnail" width="120">
                                    </div>
                                <?php endif; ?>
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="ttd" class="form-label">Tanda Tangan</label>
                                <input type="file" name="ttd" id="ttd" class="form-control form-control-lg"
                                    accept="image/*">
                                <?php if($isEdit && $user->ttd): ?>
                                    <div class="mt-2">
                                        <img src="<?php echo e(asset('storage/' . $user->ttd)); ?>" alt="TTD"
                                            class="img-thumbnail" width="120">
                                    </div>
                                <?php endif; ?>
                                <?php $__errorArgs = ['ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <?php if (! ($isEdit)): ?>
                                <div class="alert alert-info">
                                    Password default akan diset ke <b>USHBISDIG9599</b>.
                                </div>
                            <?php endif; ?>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-save me-2"></i> <?php echo e($isEdit ? 'Update User' : 'Simpan User'); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/admin/user/create.blade.php ENDPATH**/ ?>