<?php if($message = Session::get('success')): ?>
    <div class="toast-container">
        <div class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive"
            aria-atomic="true" data-bs-delay="<?php echo e(5000); ?>">
            <div class="toast-header">
                <strong class="me-auto">Information</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e($message); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="toast-container">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive"
                aria-atomic="true" data-bs-delay="<?php echo e(5000 * ($index + 1)); ?>">
                <div class="toast-header">
                    <strong class="me-auto">Information</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    <?php echo e($error); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php if($message = Session::get('warning')): ?>
    <div class="toast-container">
        <div class="toast align-items-center text-bg-warning border-0" role="alert" aria-live="assertive"
            aria-atomic="true" data-bs-delay="<?php echo e(5000); ?>">
            <div class="toast-header">
                <strong class="me-auto">Information</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e($message); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="toast-container">
        <div class="toast align-items-center text-bg-danger border-0" role="alert" aria-live="assertive"
            aria-atomic="true" data-bs-delay="<?php echo e(5000); ?>">
            <div class="toast-header">
                <strong class="me-auto">Information</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e($message); ?>

            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
    <div class="toast-container">
        <div class="toast align-items-center text-bg-primary border-0" role="alert" aria-live="assertive"
            aria-atomic="true" data-bs-delay="<?php echo e(5000); ?>">
            <div class="toast-header">
                <strong class="me-auto">Information</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?php echo e($message); ?>

            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/students/message/index.blade.php ENDPATH**/ ?>