

<?php echo $__env->make('admin.template.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.message.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="admin-container">

    <?php echo $__env->make('admin.template.sidenav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Main Content -->
    <main class="main-content">
        <header class="header">
            <div>
                <h2>Selamat <?php echo e($greeting); ?></h2>
            </div>
            <div class="user-profile">
                <div class="profile-img">
                    <?php echo e(collect(explode(' ', auth()->user()->name))->map(fn($word) => strtoupper(substr($word, 0, 1)))->join('')); ?>

                </div>

                <div class="dropdown">
                    <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <?php echo e(auth()->user()->name); ?>

                    </a>

                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('user.admin.index')); ?>" class="dropdown-item">Profile</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('admin.template.mobile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>

<?php echo $__env->make('admin.template.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/admin/template/index.blade.php ENDPATH**/ ?>