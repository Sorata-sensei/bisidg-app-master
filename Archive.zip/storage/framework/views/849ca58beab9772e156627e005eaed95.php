  <!-- Desktop Sidebar -->
  <aside class="sidebar" id="sidebar">
      <div class="logo">
          <h1>BISDIG</h1>
      </div>
      <nav>
          <ul class="nav-menu">
              <li class="nav-item">
                  <a href="<?php echo e(route('dashboard.admin.index')); ?>"
                      class="nav-link  <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                      <span class="nav-icon">📊</span>
                      Dashboard
                  </a>
              </li>
              <li class="nav-item">
                  <a href="<?php echo e(route('admin.students.index')); ?>"
                      class="nav-link <?php echo e(request()->is('admin/students') ? 'active' : ''); ?><?php echo e(request()->is('admin/students/create') ? 'active' : ''); ?>">
                      <span class="nav-icon">👥</span>
                      Students
                  </a>
              </li>
              <li class="nav-item">
                  <a href="<?php echo e(route('admin.counseling.index')); ?>"
                      class="nav-link <?php echo e(request()->is('admin/counseling') ? 'active' : ''); ?>">
                      <span class="nav-icon">📖</span>
                      Counseling
                  </a>
              </li>
              <?php if(auth()->user()->role === 'masteradmin' || auth()->user()->role === 'superadmin'): ?>
                  <li class="nav-item">
                      <a href="<?php echo e(route('user.admin.main')); ?>"
                          class="nav-link <?php echo e(request()->is('admin/user/main') ? 'active' : ''); ?>">
                          <span class="nav-icon">📖</span>
                          Lecturers
                      </a>
                  </li>
              <?php endif; ?>
          </ul>
      </nav>
  </aside>
<?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/admin/template/sidenav.blade.php ENDPATH**/ ?>