
<?php $__env->startPush('css'); ?>
    <style>
        .container {
            width: 100%;
            padding: 0;
            margin-right: auto;
            margin-left: auto;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <form action="<?php echo e(route('user.admin.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3 row">
                <label for="inputNama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputNama" name="name"
                        value="<?php echo e(old('name', $user->name)); ?>" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="inputEmail" name="email"
                        value="<?php echo e(old('email', $user->email)); ?>" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Password (opsional)</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword" name="password"
                        placeholder="Kosongkan jika tidak ingin mengganti">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="inputttd" class="col-sm-2 col-form-label">TTD</label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="inputttd" name="ttd" accept="image/*">
                    <?php if($user->ttd): ?>
                        <small class="d-block mt-2">ttd saat ini:</small>
                        <img src="<?php echo e(asset('storage/' . $user->ttd)); ?>" alt="ttd <?php echo e($user->name); ?>" class="img-thumbnail"
                            style="max-height: 120px;">
                    <?php endif; ?>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="inputphoto" class="col-sm-2 col-form-label">Photo Profil</label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="inputphoto" name="photo" accept="image/*">
                    <?php if($user->photo): ?>
                        <small class="d-block mt-2">photo saat ini:</small>
                        <img src="<?php echo e(asset('storage/' . $user->photo)); ?>" alt="photo <?php echo e($user->name); ?>"
                            class="img-thumbnail" style="max-height: 120px;">
                    <?php endif; ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">Ubah Data</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.template.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/anwar/Downloads/bisidg-app/resources/views/admin/user/index.blade.php ENDPATH**/ ?>