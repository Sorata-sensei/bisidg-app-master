@extends('admin.login.index')
<div class="login-root">
    <div class="box-root flex-flex flex-direction--column" style="min-height: 100vh;flex-grow: 1;">
        @extends('admin.login.animation')
        <div class="box-root padding-top--24 flex-flex flex-direction--column" style="flex-grow: 1; z-index: 9;">
            <div class="box-root padding-top--48 padding-bottom--24 flex-flex flex-justifyContent--center">
                <h1>Welcome</h1>
            </div>
            <div class="formbg-outer">
                <div class="formbg">
                    <div class="formbg-inner padding-horizontal--48">
                        <span class="padding-bottom--15">Input Your OTP</span>
                        <form id="stripe-login" action="{{ route('admin.otp') }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="field padding-bottom--24">
                                <label for="otps">otps</label>
                                <input type="otps" name="otps">
                            </div>

                            <div class="field padding-bottom--24">
                                <input type="submit" name="submit" value="Continue">
                            </div>

                        </form>
                    </div>
                </div>
                <div class="footer-link padding-top--24">
                    <div class="listing padding-top--24 padding-bottom--24 flex-flex center-center">
                        <span>
                            <p>Anwar Fauzi &copy; {{ now()->year }}</p>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
